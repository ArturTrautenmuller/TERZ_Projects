ExtractPath = 'C:\\TERZ\\Comex\\Extract'
TransformPath = 'C:\\TERZ\\Comex\\Transform'
ResourcesPath = 'C:\\TERZ\\Comex\\Resources'